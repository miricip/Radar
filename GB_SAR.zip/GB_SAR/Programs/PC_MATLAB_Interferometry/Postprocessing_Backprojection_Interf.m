clear all
close all

efect_corectie = 0;     %efectuare sau nu a corectiei cuplajului dintre antene
N_pix_vert=500;         %nr. pixeli imagine (pe verticala)

f_start=24.75*10^9;       %frecventa minima a chirp-ului emis [Hz]
%se definesc parametrii experimentului-------------------------------------
semiunghi=40;           %semiunghiul de deschidere al lobului de radiatie al antenei
pas_RADAR=0.01;     	%pas deplasare RADAR [m]
lungime=5;              %lungimea imaginii focalizate [m]
altitudine_scena=0; 	%altitudinea scenei fata de RADAR [m]

%constante-----------------------------------------------------------------
c = 299792458;        	%viteza luminii [m/s]
B=685e6;				%banda chirp-ului emis [Hz]
rez=c/(2*B);			%rezolutia in distnta (range) a radarului [m]

%prelucrare date brute imagine 1
corectie=load('Date\Corectie.txt');
date_brute=load('Date\Ach1.txt');
corectie=corectie';
date_brute=date_brute';
if(efect_corectie)
    date_brute=date_brute-repmat(corectie,1, size(date_brute,2));
end
matrice_domeniu_timp=fft(date_brute);
dim_utila=(size(matrice_domeniu_timp,1))/2-1;
maxR=dim_utila*rez;
s=0:rez:lungime;
matrice_domeniu_timp=matrice_domeniu_timp(1:dim_utila,:);
np=size(matrice_domeniu_timp,2);        %nr. puncte de masura
latime = pas_RADAR * (np-1);            %latime imagine focalizata [m]

N_pix_oriz=N_pix_vert*latime/lungime;

% %afisare imagine nefocalizata
% imagesc(-pas_RADAR*(np-1)/2:pas_RADAR:pas_RADAR*np/2,-s,abs(matrice_domeniu_timp(1:round(lungime/rez),:))); colormap('gray')
% caxis([0 max(max(abs(matrice_domeniu_timp)))]);
% title('Imagine nefocalizata')
% xlabel('Azimut [m]','FontSize',12); ylabel('Range [m]','FontSize',12);

%focalizare SAR
% Creeaza caroiajul imaginii scanate [m]:
x_vec=[-latime/2:latime/(N_pix_oriz-1):latime/2];
y_vec=[lungime:-lungime/(N_pix_vert-1):0];
x_mat=repmat(x_vec,length(y_vec),1);
y_mat=(repmat(y_vec,length(x_vec),1))';
z_mat=altitudine_scena*ones(length(y_vec),length(x_vec));
% Creeaza vectorul pozitiilor sistemului pe axe [m]:
AntX=[-pas_RADAR*(np-1)/2:pas_RADAR:pas_RADAR*np/2];
AntY=zeros(1,np);
AntZ=zeros(1,np);
%-------------------------- Algoritmul SAR---------------------------------
% Calculeaza distantele in range pentru fiecare element din profilul din range [m]:
r_vec = linspace(0,dim_utila-1,dim_utila)*maxR/dim_utila;
% Initializeaza imaginea:
im_final = zeros(size(x_mat));
% Initializeaza vectorul pentru masurarea duratei executiei:
t = zeros(1,np);
% Prelucreaza fiecare impuls:
for ii = 1:np
% Afiseaza timpul
if ii > 1
t_sofar = sum(t(1:(ii-1)));
t_est = (t_sofar*np/(ii-1)-t_sofar)/60;
fprintf('Impulsul %d din %d, %.02f minute pana la final\n',ii,np,t_est);
else
fprintf('Impulsul %d din %d\n',ii,np);
end
tic
% Creeaza vectorul profilului din range:
rc = matrice_domeniu_timp(:,ii);
% Calculeaza distanta dintre RADAR si locatia fiecarui pixel [m]:
dR = sqrt((AntX(ii)-x_mat).^2 + (AntY(ii)-y_mat).^2 + (AntZ(ii)-z_mat).^2);
% Calculeaza unghiul sub care se vede fiecare pixel [rad]:
unghi=atan((abs(AntX(ii)-x_mat))./(abs(AntY(ii)-y_mat)));
% Calculeaza corectia fazei pentru fiecare pixel:
phCorr = exp(1i*4*pi*f_start/c*dR);
% Determina care pixeli se gasesc in domeniul reprezentabil:
J = find(and(dR > min(r_vec), dR < max(r_vec)));
% Determina pixelii vizibili de catre antena (dn apertura reala):
I = J(find((unghi(J)) < (semiunghi * pi/180)));
% Creeaza imaginea finala folosind interpolarea liniara:
im_final(I) = im_final(I) + interp1(r_vec,rc,dR(I),'linear').* phCorr(I);
% Determina timpul de executie pentru fiecare impuls prelucrat:
t(ii) = toc;
end
% Afiseaza imaginea focalizata:
figure;
imagesc(x_vec,-y_vec,abs(im_final)); colormap('gray')
title('Imagine focalizata')
xlabel('Azimut [m]','FontSize',12); ylabel('Range [m]','FontSize',12);
caxis([0 max(max(abs(im_final)))/6]);

imagine1=im_final;

clearvars -except efect_corectie imagine1 semiunghi pas_RADAR lungime altitudine_scena c N_pix_vert f_start B rez corectie

%prelucrare date brute imagine 2
date_brute=load('Date\Ach2.txt');
date_brute=date_brute';
if(efect_corectie)
    date_brute=date_brute-repmat(corectie,1, size(date_brute,2));
end
matrice_domeniu_timp=fft(date_brute);
dim_utila=(size(matrice_domeniu_timp,1))/2-1;
maxR=dim_utila*rez;
s=0:rez:lungime;
matrice_domeniu_timp=matrice_domeniu_timp(1:dim_utila,:);
np=size(matrice_domeniu_timp,2);        %nr. puncte de masura
latime = pas_RADAR * (np-1);            %latime imagine focalizata [m]

N_pix_oriz=N_pix_vert*latime/lungime;

% %afisare imagine nefocalizata
% imagesc(-pas_RADAR*(np-1)/2:pas_RADAR:pas_RADAR*np/2,-s,abs(matrice_domeniu_timp(1:round(lungime/rez),:))); colormap('gray')
% caxis([0 max(max(abs(matrice_domeniu_timp)))]);
% title('Imagine nefocalizata')
% xlabel('Azimut [m]','FontSize',12); ylabel('Range [m]','FontSize',12);

%focalizare SAR
% Creeaza caroiajul imaginii scanate [m]:
x_vec=[-latime/2:latime/(N_pix_oriz-1):latime/2];
y_vec=[lungime:-lungime/(N_pix_vert-1):0];
x_mat=repmat(x_vec,length(y_vec),1);
y_mat=(repmat(y_vec,length(x_vec),1))';
z_mat=altitudine_scena*ones(length(y_vec),length(x_vec));
% Creeaza vectorul pozitiilor sistemului pe axe [m]:
AntX=[-pas_RADAR*(np-1)/2:pas_RADAR:pas_RADAR*np/2];
AntY=zeros(1,np);
AntZ=zeros(1,np);
%-------------------------- Algoritmul SAR---------------------------------
% Calculeaza distantele in range pentru fiecare element din profilul din range [m]:
r_vec = linspace(0,dim_utila-1,dim_utila)*maxR/dim_utila;
% Initializeaza imaginea:
im_final = zeros(size(x_mat));
% Initializeaza vectorul pentru masurarea duratei executiei:
t = zeros(1,np);
% Prelucreaza fiecare impuls:
for ii = 1:np
% Afiseaza timpul
if ii > 1
t_sofar = sum(t(1:(ii-1)));
t_est = (t_sofar*np/(ii-1)-t_sofar)/60;
fprintf('Impulsul %d din %d, %.02f minute pana la final\n',ii,np,t_est);
else
fprintf('Impulsul %d din %d\n',ii,np);
end
tic
% Creeaza vectorul profilului din range:
rc = matrice_domeniu_timp(:,ii);
% Calculeaza distanta dintre RADAR si locatia fiecarui pixel [m]:
dR = sqrt((AntX(ii)-x_mat).^2 + (AntY(ii)-y_mat).^2 + (AntZ(ii)-z_mat).^2);
% Calculeaza unghiul sub care se vede fiecare pixel [rad]:
unghi=atan((abs(AntX(ii)-x_mat))./(abs(AntY(ii)-y_mat)));
% Calculeaza corectia fazei pentru fiecare pixel:
phCorr = exp(1i*4*pi*f_start/c*dR);
% Determina care pixeli se gasesc in domeniul reprezentabil:
J = find(and(dR > min(r_vec), dR < max(r_vec)));
% Determina pixelii vizibili de catre antena (dn apertura reala):
I = J(find((unghi(J)) < (semiunghi * pi/180)));
% Creeaza imaginea finala folosind interpolarea liniara:
im_final(I) = im_final(I) + interp1(r_vec,rc,dR(I),'linear').* phCorr(I);
% Determina timpul de executie pentru fiecare impuls prelucrat:
t(ii) = toc;
end
% Afiseaza imaginea focalizata:
figure;
imagesc(x_vec,-y_vec,abs(im_final)); colormap('gray')
title('Imagine focalizata')
xlabel('Azimut [m]','FontSize',12); ylabel('Range [m]','FontSize',12);
caxis([0 max(max(abs(im_final)))/6]);

imagine2=im_final;

%eliminare zona camp apropiat
imagine1(size(imagine1,1)-30:size(imagine1,1),:)=0;
imagine2(size(imagine2,1)-30:size(imagine2,1),:)=0;

%aliniere imagini <co-registration>
n = 10;%deplasare in pixeli dreapta-stanga, sus-jos

for i=[1:2*n+1]
    for j=[1:2*n+1]
        cor(i,j)=sum(sum(abs(imagine1(i:i-1+size(imagine1,1)-2*n,j:j-1+size(imagine1,2)-2*n)).*abs(imagine2(n+1:size(imagine2,1)-n,n+1:size(imagine2,2)-n))));
    end
end

maximum = max(max(cor));
[i,j]=find(cor==maximum);

%prelucrare interferometrica
%interferograma=imagine1 .* conj(imagine2);
interferograma=imagine1(i:i-1+size(imagine1,1)-2*n,j:j-1+size(imagine1,2)-2*n).*conj(imagine2(n+1:size(imagine2,1)-n,n+1:size(imagine2,2)-n));
%bordeaza cu zero-uri
interferograma=[zeros(size(interferograma,1),n), interferograma, zeros(size(interferograma,1),n)];%orizontala
interferograma=[zeros(n,size(interferograma,2)); interferograma; zeros(n,size(interferograma,2))];%verticala

% Afiseaza modulul interferogramei:
figure;
imagesc(x_vec,-y_vec,abs(interferograma)); colormap('gray')
title('Valoare absoluta interferograma')
xlabel('Azimuth [m]','FontSize',12); ylabel('Range [m]','FontSize',12);
caxis([0 max(max(abs(interferograma)))/36]);

% Afiseaza unghiul interferogramei:
figure;
imagesc(x_vec,-y_vec,angle(interferograma)); %colormap('gray')
title('Faza interferograma')
xlabel('Azimuth [m]','FontSize',12); ylabel('Range [m]','FontSize',12);

%calculeaza matricea deplasarilor
lambda = c / f_start; %c / frecventa minima
deplasari=angle(interferograma) * lambda / (4*pi);
deplasari = deplasari * 100; %in cm

prag=max(max(abs(interferograma))) * 40 / 100; %prag afisare deplasari
deplasari(abs(interferograma)<prag)=0;

% Afiseaza deplasari:
figure;
imagesc(x_vec,-y_vec,deplasari); %colormap('gray')
title('Deplasari [cm]')
xlabel('Azimuth [m]','FontSize',12); ylabel('Range [m]','FontSize',12);
caxis([min(min(deplasari)) max(max(deplasari))]);