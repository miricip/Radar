clear all

N_pix_vert=500;         %nr. pixeli imagine (pe verticala)

f_start=24.75*10^9;       %frecventa minima a chirp-ului emis
%se definesc parametrii experimentului-------------------------------------
semiunghi=40;           %semiunghiul de deschidere al lobului de radiatie al antenei
pas_RADAR=0.01;     	%pas deplasare RADAR [m]
lungime=5;              %lungimea imaginii focalizate [m]
altitudine_scena=0; 	%altitudinea scenei fata de RADAR [m]

%constante-----------------------------------------------------------------
c = 299792458;        	%viteza luminii [m/s]
B=685e6;				%banda chirp-ului emis [Hz]
rez=c/(2*B);			%rezolutia in distnta (range) a radarului

%prelucrare date brute
corectie=load('Date\Corectie.txt');
date_brute=load('Date\Ach.txt');
corectie=corectie';
date_brute=date_brute';
date_brute=date_brute-repmat(corectie,1, size(date_brute,2));

%date_brute=hilbert(date_brute);

matrice_domeniu_timp=fft(date_brute);
dim_utila=(size(matrice_domeniu_timp,1))/2-1;
maxR=dim_utila*rez;
s=0:rez:lungime;
matrice_domeniu_timp=matrice_domeniu_timp(1:dim_utila,:);
np=size(matrice_domeniu_timp,2);        %nr. puncte de masura
latime = pas_RADAR * (np-1);            %latime imagine focalizata [m]

N_pix_oriz=N_pix_vert*latime/lungime;

%afisare imagine nefocalizata
figure
imagesc(-pas_RADAR*(np-1)/2:pas_RADAR:pas_RADAR*np/2,-s,abs(matrice_domeniu_timp(1:round(lungime/rez),:))); colormap('gray')
caxis([0 max(max(abs(matrice_domeniu_timp)))]);
title('Imagine nefocalizata')
xlabel('Azimut [m]','FontSize',12); ylabel('Range [m]','FontSize',12);

%focalizare SAR
% Creeaza caroiajul imaginii scanate [m]:
x_vec=[-latime/2:latime/(N_pix_oriz-1):latime/2];
y_vec=[lungime:-lungime/(N_pix_vert-1):0];
x_mat=repmat(x_vec,length(y_vec),1);
y_mat=(repmat(y_vec,length(x_vec),1))';
z_mat=altitudine_scena*ones(length(y_vec),length(x_vec));
% Creeaza vectorul pozitiilor sistemului pe axe [m]:
AntX=[-pas_RADAR*(np-1)/2:pas_RADAR:pas_RADAR*np/2];
AntY=zeros(1,np);
AntZ=zeros(1,np);
%-------------------------- Algoritmul SAR---------------------------------
% Calculeaza distantele in range pentru fiecare element din profilul din range [m]:
r_vec = linspace(0,dim_utila-1,dim_utila)*maxR/dim_utila;
% Initializeaza imaginea:
im_final = zeros(size(x_mat));
% Initializeaza vectorul pentru masurarea duratei executiei:
t = zeros(1,np);
% Prelucreaza fiecare impuls:
for ii = 1:np
% Afiseaza timpul
if ii > 1
t_sofar = sum(t(1:(ii-1)));
t_est = (t_sofar*np/(ii-1)-t_sofar)/60;
fprintf('Impulsul %d din %d, %.02f minute pana la final\n',ii,np,t_est);
else
fprintf('Impulsul %d din %d\n',ii,np);
end
tic
% Creeaza vectorul profilului din range:
rc = matrice_domeniu_timp(:,ii);
% Calculeaza distanta dintre RADAR si locatia fiecarui pixel [m]:
dR = sqrt((AntX(ii)-x_mat).^2 + (AntY(ii)-y_mat).^2 + (AntZ(ii)-z_mat).^2);
% Calculeaza unghiul sub care se vede fiecare pixel [rad]:
unghi=atan((abs(AntX(ii)-x_mat))./(abs(AntY(ii)-y_mat)));
% Calculeaza corectia fazei pentru fiecare pixel:
phCorr = exp(1i*4*pi*f_start/c*dR);
% Determina care pixeli se gasesc in domeniul reprezentabil:
J = find(and(dR > min(r_vec), dR < max(r_vec)));
% Determina pixelii vizibili de catre antena (dn apertura reala):
I = J(find((unghi(J)) < (semiunghi * pi/180)));
% Creeaza imaginea finala folosind interpolarea liniara:
im_final(I) = im_final(I) + interp1(r_vec,rc,dR(I),'linear').* phCorr(I);
% Determina timpul de executie pentru fiecare impuls prelucrat:
t(ii) = toc;
end
% Afiseaza imaginea focalizata:
figure;
imagesc(x_vec+max(x_vec),-y_vec,abs(im_final)); %colormap('gray')
title('Focused image')
xlabel('x [m]','FontSize',12); ylabel('-y [m]','FontSize',12);
caxis([0 max(max(abs(im_final)))]);
