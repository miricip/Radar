clear all
close all

nr_pct_mas_brazda=37;   %numar puncte de masura per brazda
pas_intre_brazde=0.1;   %pas intre brazde [m]
adancime_max=1.9708;    %adancime maxima afisata [m]

%constante-----------------------------------------------------------------
pas_RADAR=0.03;     	%pas deplasare RADAR [m]
c = 3e8;                %viteza luminii [m/s]
B=685e6;				%banda chirp-ului emis [Hz]
rez=c/(2*B);			%rezolutia in distanta (range) a radarului

%prelucrare date brute
corectie=load('Date\Corectie.txt'); %cuplaj antene
date_brute=load('Date\Ach.txt');
corectie=corectie';
date_brute=date_brute';

date_brute=date_brute-repmat(corectie,1, size(date_brute,2));   %efectuare corectie cuplaj antene
matrice_GPR=fft(date_brute);
clear date_brute corectie
adancime=0:rez:adancime_max;                                    %vector adancimi
matrice_GPR=matrice_GPR(1:length(adancime),:);                  %extragere zona vizibila
np=size(matrice_GPR,2);                                         %nr. puncte de masura
latime = pas_RADAR * (np-1);                                    %latime imagine [m]

% %afisare imagine desfasurata
% figure;
% imagesc(0:pas_RADAR:latime,adancime,abs(matrice_GPR(1:length(adancime),:))); %colormap('gray')
% caxis([0 150000]);
% title('Imagine desfasurata')
% xlabel('Distanta [m]','FontSize',12); ylabel('Adancime [m]','FontSize',12);

matrice_GPR_3D=reshape(matrice_GPR, size(matrice_GPR,1), int16(nr_pct_mas_brazda), int16(size(matrice_GPR,2)/nr_pct_mas_brazda));
clear matrice_GPR
matrice_GPR_3D=permute(matrice_GPR_3D,[3 2 1]);
x = 0:pas_RADAR:pas_RADAR*(nr_pct_mas_brazda-1);
y = 0:pas_intre_brazde:(size(matrice_GPR_3D,1)-1)*pas_intre_brazde;
z = -adancime;
[x,y,z] = meshgrid(x,y,z);

%taieturi
xslice = pas_RADAR*(nr_pct_mas_brazda-1); 
yslice = 0.35;      %(size(matrice_GPR_3D,1)-1)*pas_intre_brazde;
zslice = -1.7;        

% figure;
% slice(x,y,z,abs(matrice_GPR_3D),xslice,yslice,zslice);
% caxis([0 160000]);
% xlabel('Dist. deplasare [m]');
% ylabel('Dist. perpendiculara [m]');
% zlabel('Adancime  [m]');

%vizualizare animatie
figure
xslice = pas_RADAR*(nr_pct_mas_brazda-1); 
yslice = (size(matrice_GPR_3D,1)-1)*pas_intre_brazde;

for zslice = [0:-0.05:-1.7]    
    slice(x,y,z,abs(matrice_GPR_3D),xslice,yslice,zslice);
    caxis([0 160000]);
    xlabel('Dist. deplasare [m]');
    ylabel('Dist. perpendiculara [m]');
    zlabel('Adancime  [m]');
    pause(0.2);
end

for yslice = [(size(matrice_GPR_3D,1)-1)*pas_intre_brazde:-0.025:0]    
    slice(x,y,z,abs(matrice_GPR_3D),xslice,yslice,zslice);
    caxis([0 160000]);
    xlabel('Dist. deplasare [m]');
    ylabel('Dist. perpendiculara [m]');
    zlabel('Adancime  [m]');
    pause(0.2);
end